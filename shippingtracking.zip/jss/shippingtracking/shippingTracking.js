function viewDashboard()
{
		document.forms[0].action="ShowDashboardAction.do";
		document.forms[0].submit();
}