function viewDashboard()
{
		document.forms[0].action="ShowDashboardAction.do";
		document.forms[0].submit();
}
// Global variables.
var ACCEPT = "Accept";
var REJECT_AND_DESTROY = "Reject & Destroy";
var REJECT_AND_RESEND = "Reject & Resend";

// Set activityStatus to "Reject & Resend" for selected items.
function setRejectAndResend(choiceSpecimenContainer) {
	var chkBoxArr;
	if  (choiceSpecimenContainer == 'specimen') {
		chkBoxArr = document.getElementsByName('chkSpecimenId');
	} else {
		chkBoxArr = document.getElementsByName('chkStorgaeContainerId');
	}
	
	//check whether the CheckBox exists or Not
	if(chkBoxArr) {
		var chkLen = chkBoxArr.length;
		if(chkLen) {
			for(i =0; i<chkLen; i++) {
				if(chkBoxArr[i].checked) {
					// change item's activity status = "Reject & Resend"
					if  (choiceSpecimenContainer == 'specimen') {
						document.getElementById('specimenItem[' + i + '].activityStatus').value = REJECT_AND_RESEND
					} else {
						document.getElementById('containerItem[' + i + '].activityStatus').value = REJECT_AND_RESEND
					}
				}
			}
		}
	} 
}

// Set activityStatus to "Reject & Destroy" for selected items.
function setRejectAndDestroy(choiceSpecimenContainer) {
	var chkBoxArr;
	if  (choiceSpecimenContainer == 'specimen') {
		chkBoxArr = document.getElementsByName('chkSpecimenId');
	} else {
		chkBoxArr = document.getElementsByName('chkStorgaeContainerId');
	}

	//check whether the CheckBox exists or Not
	if(chkBoxArr) {
		var chkLen = chkBoxArr.length;
		if(chkLen) {
			for(i =0; i<chkLen; i++) {
				if(chkBoxArr[i].checked) {
					// change item's activity status = "Reject & Resend"
					if  (choiceSpecimenContainer == 'specimen') {
						document.getElementById('specimenItem[' + i + '].activityStatus').value = REJECT_AND_DESTROY
					} else {
						document.getElementById('containerItem[' + i + '].activityStatus').value = REJECT_AND_DESTROY
					}
				}
			}
		}
	} 
}

// Select/Deselect All checkboxes.
function selectAllCheckBox(selectAllChkBoxName,chkBoxNameInEachRow)
{
	var chkBoxObj = document.getElementById(selectAllChkBoxName);
	var chkBoxInEachRow = document.getElementsByName(chkBoxNameInEachRow);
	var i =0;
	var len = chkBoxInEachRow.length;
	if(chkBoxObj)
	{
		//If checkAll checkbox is checked then checked all the checkbox in the List
		if(chkBoxObj.checked == true)
		{
			if(chkBoxInEachRow)
			{
				for(i =0;i<len;i++)
				{
					chkBoxInEachRow[i].checked = true;
				}
			}
		}
		//If checkAll checkbox is Not checked then Unchecked all the checkbox in the List
		else if(chkBoxObj.checked == false)
		{
			if(chkBoxInEachRow)
			{
				for(i =0;i<len;i++)
				{
					chkBoxInEachRow[i].checked = false;
				}
			}
		}
	}
}//End of Function


//To be used on Shipment Receiving page
var winNew = null;
function StorageMapWindowShipReceive(mypage,myname,w,h,scroll,containerNameControlId)
{
			LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
			TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
			// Sri: Added position one and two as parameters
            // with format positionOne:positionTwo
			mypage=mypage+"1" + 
					"&storageToBeSelected="+ document.forms[0].customListBox_1_0.value +  //parentContainerId.value +
					"&position=" + document.forms[0].customListBox_1_1.value +   //positionDimensionOne.value + 
					":" + document.forms[0].customListBox_1_2.value;
					
		   var storageContainer = document.getElementById(containerNameControlId).value;
		   mypage+="&storageContainerName="+storageContainer;		
					// alert(mypage);
			settings =
				'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'

			winNew = open(mypage,myname,settings)
			if (winNew.opener == null)
				winNew.opener = self;
}