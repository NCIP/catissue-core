//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["5E"] = '<layout><autosize hor="a;b;c;d;e" ver="e" rows="5" cols="1"/><table data="a;b;c;d;e"/><row><cell obj="a" wh="1,5" resize="ver" neighbors="a;b;c;d;e"/></row><row sep="yes"><cell sep="hor" top="a" bottom="b;c;d;e" dblclick="a"/></row><row><cell obj="b" wh="1,5" resize="ver" neighbors="a;b;c;d;e"/></row><row sep="yes"><cell sep="hor" top="a;b" bottom="c;d;e" dblclick="b"/></row><row><cell obj="c" wh="1,5" resize="ver" neighbors="a;b;c;d;e"/></row><row sep="yes"><cell sep="hor" top="a;b;c" bottom="d;e" dblclick="c"/></row><row><cell obj="d" wh="1,5" resize="ver" neighbors="a;b;c;d;e"/></row><row sep="yes"><cell sep="hor" top="a;b;c;d" bottom="e" dblclick="d"/></row><row><cell obj="e" wh="1,5" resize="ver" neighbors="a;b;c;d;e"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["5E_hor"] = new Array("a;b;c;d;e");dhtmlXLayoutObject.prototype._availAutoSize["5E_ver"] = new Array("a", "b", "c", "d", "e");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/