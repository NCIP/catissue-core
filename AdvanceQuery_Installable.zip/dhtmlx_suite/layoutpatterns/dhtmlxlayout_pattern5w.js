//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["5W"] = '<layout><autosize hor="e" ver="a;b;c;d;e" rows="1" cols="5"/><table data="a,b,c,d,e"/><row><cell obj="a" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a" right="b;c;d;e" dblclick="a"/><cell obj="b" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b" right="c;d;e" dblclick="b"/><cell obj="c" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b;c" right="d;e" dblclick="c"/><cell obj="d" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/><cell sep="ver" left="a;b;c;d" right="e" dblclick="d"/><cell obj="e" wh="5,1" resize="hor" neighbors="a;b;c;d;e"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["5W_hor"] = new Array("a", "b", "c", "d", "e");dhtmlXLayoutObject.prototype._availAutoSize["5W_ver"] = new Array("a;b;c;d;e");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/