//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["4W"] = '<layout><autosize hor="d" ver="a;b;c;d" rows="1" cols="4"/><table data="a,b,c,d"/><row><cell obj="a" wh="4,1" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="a" right="b;c;d" dblclick="a"/><cell obj="b" wh="4,1" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="a;b" right="c;d" dblclick="b"/><cell obj="c" wh="4,1" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="a;b;c" right="d" dblclick="c"/><cell obj="d" wh="4,1" resize="hor" neighbors="a;b;c;d"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["4W_hor"] = new Array("a", "b", "c", "d");dhtmlXLayoutObject.prototype._availAutoSize["4W_ver"] = new Array("a;b;c;d");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/