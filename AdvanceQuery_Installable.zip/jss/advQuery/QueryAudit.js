 var pageNum = 1;
var auditGridBox = null;
var params = null;
var filterVal = null;
var startIndex = 0;
window.onload = function() {   
	auditGridBox = new dhtmlXGridObject('auditGridbox');
	auditGridBox.setImagePath("dhtmlx_suite/imgs/");
	auditGridBox.setHeader("<b>Query Id,<b>Query Title,<b>Executed On,<b>Executed By,<b>Execution Time(Seconds),<b>Generated SQL");
	auditGridBox.attachHeader("#text_filter,#text_filter,#rspan,#select_filter,#rspan,#rspan"); 
	auditGridBox.setInitWidthsP("7,*,15,15,11,7");
	auditGridBox.setColAlign("center, left, center, left, right, center");
	auditGridBox.setColSorting("int,str,date,str,int,str");
	auditGridBox.setSkin("dhx_skyblue"); // (xp, mt, gray, light, clear, modern)
	auditGridBox.setEditable(false);
	auditGridBox.enableTooltips("false,true,true,false,false,false");
	auditGridBox.clearAll(true);
	//auditGridBox.attachEvent("onBeforePageChanged", onBeforePageChanged);
	auditGridBox.attachEvent("onFilterStart", onFilter);
	auditGridBox.attachEvent("onBeforeSorting", onBeforeSort);	
	auditGridBox.init();
	auditGridBox.enablePaging(true,200,15,"pagingArea",true);
	auditGridBox.setPagingSkin("bricks");	
	auditGridBox.parse(gridDataJson, "json");

	if(auditGridBox.getRowsNum() == 10000) {
		document.getElementById("messageDiv").style.display = "block";
		document.getElementById("messageDiv").style.color = "blue";
		document.getElementById("messageDiv").textContent = "Showing the recent 10000 logs. Use filter to see specific log details.";
		document.getElementById("messageDiv").innerText = "Showing the recent 10000 logs. Use filter to see specific log details.";
	}
}  

var xmlHttpobj = null;
function initAjaxPostCall(params){
	var url = "QueryRunAudit.do"; 
	if (window.XMLHttpRequest){
		xmlHttpobj=new XMLHttpRequest();
	}else {
		xmlHttpobj=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlHttpobj.onreadystatechange = populateGrid;
	xmlHttpobj.open("POST", url ,false);
	xmlHttpobj.setRequestHeader("Content-Type",
			"application/x-www-form-urlencoded");
	xmlHttpobj.send(params);
}

function populateGrid(){
	if (xmlHttpobj.readyState == 4) 
	{
		 var jsonObj = eval('('+ xmlHttpobj.responseText +')');
		 auditGridBox.parse(jsonObj, "json");
	}
}

function showGeneratedSQL(auditId){
	var url = "QueryRunAudit.do?operation=showSQL&auditId="+auditId;
	window.open(url);
}

var addElement = false; 
function addRecordPerPageOption() {		
	toolbar = auditGridBox.aToolBar;
	toolbar.setWidth('perpagenum', 130);
	
	var  opt = [10, 50, 100 , 200, 300, 500];
	
	for(i = 5; i < 35; i += 5) {
		toolbar.removeListOption('perpagenum', 'perpagenum_'+i);
	}

	for(i = 0; i < opt.length; i++) {
		toolbar.addListOption('perpagenum', 'perpagenum_'+ opt[i], NaN, "button", opt[i]+" "+ auditGridBox.i18n.paging.perpage);
	}
	 
	toolbar.setListOptionSelected('perpagenum', 'perpagenum_' + recordPerPage);
	setPageDivStyle();
}

function setPageDivStyle() {
	if (document.getElementsByClassName) { 		
		pageDiv = document.getElementsByClassName('dhx_toolbar_poly_dhx_skyblue')[0]; 
		pageDiv.style.maxHeight = "210px"
		pageDiv.style.overflowY = "auto"
	} else { 		
		var elements = document.getElementsByTagName('div');
		for(i = 0; i < elements.length; i++) {
			if(elements[i].className == 'dhx_toolbar_poly_dhx_skyblue') {
				pageDiv = elements[i];				
				if(pageDiv.childNodes.length < 10) {
					pageDiv.style.height = 21 * pageDiv.childNodes.length + "px"					
				} else {
					pageDiv.style.height = 21 * 10 + "px"
					pageDiv.style.width = "96px";
					pageDiv.style.overflowY = "auto"
				}				
				break;
			}
		}
	}
} 

function getJsonForFilter() {
	var columns = []
	var values = []
	var j = 0;
	for(i = 0; i < 4; i++) {
		if(auditGridBox.getFilterElement(i)){
			var value = auditGridBox.getFilterElement(i).value;			
			if(value != "") {
				columns[j] = auditGridBox.getColumnLabel(i, 0);
				values[j++] = value;				
			}
		}
	}
	//var sortColumn = sortIndex ? auditGridBox.getColumnLabel(sortIndex, 0): "";
	//sortDirection = sortDirection == "asc" ? sortDirection: "desc";
	
	return JSON.stringify({"columns": columns, "values": values/*, "sortColumn": sortColumn ,"sortDir": sortDirection*/});
}

function onFilter(indexes,values){
	auditGridBox.clearAll();
	//var option = auditGridBox.aToolBar.getListOptionSelected('perpagenum').split("_");
	//pageNum = 1;
	//recordPerPage = option[1];  
	//startIndex = (pageNum - 1) * recordPerPage;
	params = "&operation=gridData&filterValues="+getJsonForFilter()+"&startIndex=0&recordPerPage=10000"
	initAjaxPostCall(params);
	document.getElementById("messageDiv").style.display = "none";
	return true;
}

var sortOrder = "Desc";
function onBeforeSort(ind, type, direction){  
	sortOrder = direction;
	if (ind == 2) {
		this.setSortImgState(true, ind, direction);   //set a correct sorting image	
		this.clearAll();
		params = "&operation=gridData&filterValues="+getJsonForFilter()+"&startIndex=0&recordPerPage=10000&sortOrder="+sortOrder;
		initAjaxPostCall(params);
	}  
	return true;   
}

function onBeforePageChanged(ind, count){
	var option = auditGridBox.aToolBar.getListOptionSelected('perpagenum').split("_");
	auditGridBox.clearAll();
	pageNum = count;
	recordPerPage = option[1];  
	startIndex = (pageNum - 1) * recordPerPage	
	return true;
}
