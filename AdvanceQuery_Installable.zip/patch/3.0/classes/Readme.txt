#Classes in common-package folder are comming from Plus common-package branch. 
Changes :
1)Tags package (contains all code required for query folder module).

Contact at www.krishagni.com fro more details.

#Classes in washu-commons folder are comming from Plus washu-commons branch. 
Contact at www.krishagni.com fro more details.

Changes :
1)senEmail.class.
