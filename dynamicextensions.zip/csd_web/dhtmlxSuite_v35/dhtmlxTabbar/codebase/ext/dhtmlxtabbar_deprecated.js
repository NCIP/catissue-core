//v.3.5 build 120822

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXTabBar.prototype.setOnLoadingEnd=function(a){this.attachEvent("onXLE",a)};dhtmlXTabBar.prototype.setOnTabContentLoaded=function(a){this.attachEvent("onTabContentLoaded",a)};dhtmlXTabBar.prototype.setOnTabClose=function(a){this.attachEvent("onTabClose",a)};dhtmlXTabBar.prototype.setOnSelectHandler=function(a){this.attachEvent("onSelect",a)};

//v.3.5 build 120822

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/