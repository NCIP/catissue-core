import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import edu.wustl.common.util.global.Constants;



public class bulkInsert
{
	public static void main(String[] args)
	{
		Connection conn = null;

        try
        {
            String userName = "catissue_prafull";
            String password = "catissue_prafull";
            String url = "jdbc:oracle:thin:@10.88.199.74:1521:washu";

            Class.forName ("oracle.jdbc.driver.OracleDriver").newInstance ();
            conn = DriverManager.getConnection (url, userName, password);
            System.out.println ("Database connection established");
            
            
            
            String query = "insert into catissue_site (identifier, name) values (1,'sp1')";
//            String query = "insert into catissue_specimen (identifier, label, specimen_class, type, Activity_status) values (2,'sp2','Tissue','Fixed Tissue','Active' )";
			PreparedStatement stmt = conn.prepareStatement(query);
    		long time = System.currentTimeMillis();
    		for (int i=2420;i<24200;i++)
    		{
    			
        		
        		query = "insert into catissue_site (identifier, name) values ("+i+",'site"+i+"')";
//        		query = "insert into temp (identifier, label) values ("+i+",'sp"+i+"')";
        		stmt.executeUpdate(query);
        		
    		}
    		stmt.close();
    		
    		
   		
        }
        catch (Exception e)
        {
        	e.printStackTrace();
            System.err.println ("Cannot connect to database server");
        }
        finally
        {
            if (conn != null)
            {
                try
                {
                    conn.close ();
                    System.out.println ("Database connection terminated");
                }
                catch (Exception e) { /* ignore close errors */ }
            }
        }
	}
}
