/**
 * <p>Title: AddNewAction Class>
 * <p>Description:	This Class is used to maintain FormBean for AddNew operation</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Krunal Thakkar
 * @version 1.00
 * Created on Apr 12, 2006
 */

package edu.wustl.common.action;

import java.util.List;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.AddNewSessionDataBean;
import edu.wustl.common.util.global.Constants;
import edu.wustl.common.util.logger.Logger;

/**
 * This Class is used to maintain FormBean for AddNew operation.
 * @author Krunal Thakkar
 */
public class AddNewAction extends Action 
{
    /**
     * Overrides the execute method of Action class.
     * Maintains FormBean for AddNew operation.
     * */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        try
        {
              Logger.out.debug("-----------------------------AddNewAction-----------------------------");
            //Populating ADDNewSessionDataBean to store FormBean into Session and Path to redirect 
	        AddNewSessionDataBean addNewSessionDataBean=new AddNewSessionDataBean();
	           
	        //String firstName = (String)request.getParameter("firstName");
	       
	        //Storing FormBean into AddNewSessionDataBean
	        addNewSessionDataBean.setAbstractActionForm((AbstractActionForm)form);
	        Logger.out.debug("ActionForm in AddNewAction----"+form);
	        	        
	        //Getting ForwardTo attribute from Request
	        String forwardTo=(String)request.getParameter(Constants.FORWARD_TO);
	       //System.out.println("Forward to :"+forwardTo); 
	        
	        Logger.out.debug("forwardTo stored in AddNewSessionDataBean------>"+forwardTo);
	        
	        //Storing forwardTo of InitializeAction into AddNewSessionDataBean
	        addNewSessionDataBean.setForwardTo(forwardTo);
	        
	        Logger.out.debug("AddNewAction:::Forward To ------------"+addNewSessionDataBean.getForwardTo());
	        
	        //Getting AddNewFor attribute from Request
	       String addNewFor =(String)request.getParameter(Constants.ADD_NEW_FOR);
	        
	        //Storing addNewFor of InitializeAction into AddNewSessionDataBean
	        addNewSessionDataBean.setAddNewFor(addNewFor);
	        
	        //Retrieving current Session
	        HttpSession session = request.getSession();
	        
	        //Storing Stack of FormBean into Session
	        Stack formBeanStack=(Stack)session.getAttribute(Constants.FORM_BEAN_STACK);
	        
	        if(formBeanStack ==null)
	        {
	            Logger.out.debug("Creating FormBeanStack in AddNewAction.......................");
	            formBeanStack=new Stack();
	        }
	        
	        formBeanStack.push(addNewSessionDataBean);
	        
	        
	        /**
	         * Modified By Baljeet
	         */
	       /* boolean readOnlyValue = false; 
	        String formName = "UserAdd.do";
	        request.setAttribute("formName",formName);
	        request.setAttribute("prevPageURL", null);
	        request.setAttribute("nextPageURL", null);
	       // request.setAttribute("pageOf", "pageOfUserAdmin");
	        request.setAttribute("Approve", Constants.APPROVE_USER_APPROVE_STATUS);
			//request.setAttribute("pageOfApproveUser",Constants.PAGEOF_APPROVE_USER);
			//request.setAttribute("backPage", Constants.APPROVE_USER_SHOW_ACTION+"?"+Constants.PAGE_NUMBER+"="+Constants.START_PAGE);
			request.setAttribute("redirectTo", "redirectTo");
	        //request.setAttribute("redirectTo",redirectTo);
	        request.setAttribute("submittedFor",submittedFor);
	        request.setAttribute("addforJSP", Constants.ADD);
			request.setAttribute("editforJSP", Constants.EDIT);
			request.setAttribute("searchforJSP", Constants.SEARCH);
			request.setAttribute("readOnlyEmail", true);
			request.setAttribute("pageOfUserProfile",Constants.PAGEOF_USER_PROFILE);
			request.setAttribute("pageOfUserAdmin", Constants.PAGEOF_USER_ADMIN);
			request.setAttribute("pageOfSignUp", Constants.PAGEOF_SIGNUP);
			request.setAttribute("pageOf", pageOf);
			request.setAttribute("operation", operation);
			request.setAttribute("readOnlyValue",readOnlyValue);
			
			*/
	        /**
	         *  Baljeet's changes ends here 
	         */
	        
	        session.setAttribute(Constants.FORM_BEAN_STACK, formBeanStack);
	     
	        //Storing required Attributes into Request
	        request.setAttribute(Constants.SUBMITTED_FOR , "AddNew");
	        
	        Logger.out.debug("ForwardTo attribute----------------"+request.getParameter(Constants.ADD_NEW_FORWARD_TO));
	    	request.setAttribute("addNewFor",addNewFor);
	        request.setAttribute("isPopupOpen","true");
	        //Forwarding to ADD_NEW_FORWARD_TO Action
	    	return mapping.findForward("addNew");
	        //return mapping.findForward((String)request.getParameter(Constants.ADD_NEW_FORWARD_TO));
        }
        catch(Exception e)
        {
            Logger.out.info("Exception: " + e.getMessage(), e);
            
            return mapping.findForward(Constants.SUCCESS);
        }
    }
}
