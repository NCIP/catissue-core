
package edu.wustl.common.querysuite.exceptions;

public class DuplicateChildException extends Exception
{

}
