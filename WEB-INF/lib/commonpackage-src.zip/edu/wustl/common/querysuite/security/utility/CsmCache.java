/**
 * 
 */
package edu.wustl.common.querysuite.security.utility;

import java.util.HashMap;
import java.util.Map;


/**
 * This class maintains cache related to Read and Identified Data Privileges for a particular user on CP ids to 
 * which objects in Query are related.
 * @author supriya_dankh
 *
 */
public class CsmCache
{

	private Map<Long, Boolean> ReadPrivilegeMap ;
	private Map<Long, Boolean> IdentifiedDataAccsessMap ;
	
	public CsmCache()
	{     
		ReadPrivilegeMap = new HashMap<Long, Boolean>();
		IdentifiedDataAccsessMap = new HashMap<Long, Boolean>();
	}
	public Boolean isReadDenied(Long id)
	{  
		Boolean isReadDenied = ReadPrivilegeMap.get(id);
		return isReadDenied;
	} 
	
	public Boolean isIdentifedDataAccess(Long id)
	{ 
		Boolean isIdentified = this.IdentifiedDataAccsessMap.get(id);
		return isIdentified;
	}
	
	public void addNewObjectInReadPrivilegeMap(Long id,Boolean isAuthorized)
	{
		ReadPrivilegeMap.put(id, isAuthorized);
	}
	
	public void removeObjectFromReadPrivilegeMap(Long id)
	{
		ReadPrivilegeMap.remove(id);
	}
	
	public void addNewObjectInIdentifiedDataAccsessMap(Long id,Boolean isAuthorized)
	{
		IdentifiedDataAccsessMap.put(id, isAuthorized);
	}
	
	public void removeObjectFromIdentifiedDataAccsessMap(Long id)
	{
		IdentifiedDataAccsessMap.remove(id);
	}

}
