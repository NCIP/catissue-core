package edu.wustl.common.lookup;

/**
 * MatchingStatusForSSNPMI enum.
 *
 */
public enum MatchingStatusForSSNPMI
{
	/**
	 * MatchingStatusForSSNPMI enum values.
	 */
	EXACT, ONEMATCHOTHERNULL,ONEMATCHOTHERMISMATCH, NOMATCH;
}
