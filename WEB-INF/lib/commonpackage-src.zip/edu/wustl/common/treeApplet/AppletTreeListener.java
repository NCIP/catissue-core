package edu.wustl.common.treeApplet;

import java.awt.event.MouseEvent;

import javax.swing.event.MouseInputListener;

public class AppletTreeListener implements MouseInputListener 
{

	public void mouseClicked(MouseEvent arg0) 
	{
		
	}

	public void mousePressed(MouseEvent arg0) 
	{
	
	}

	public void mouseReleased(MouseEvent arg0) 
	{
		
	}

	public void mouseEntered(MouseEvent arg0) 
	{
	
	}

	public void mouseExited(MouseEvent arg0) 
	{
		
	}

	public void mouseDragged(MouseEvent arg0) 
	{
		
	}

	public void mouseMoved(MouseEvent arg0) 
	{
		
	}

}
