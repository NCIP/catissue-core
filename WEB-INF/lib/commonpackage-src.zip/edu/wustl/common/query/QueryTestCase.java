/*
 * Created on Jul 24, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.query;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.log4j.PropertyConfigurator;

import edu.wustl.common.bizlogic.QueryBizLogic;
import edu.wustl.common.exception.BizLogicException;
import edu.wustl.common.test.BaseTestCase;
import edu.wustl.common.util.global.Constants;
import edu.wustl.common.util.global.Variables;
import edu.wustl.common.util.logger.Logger;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class QueryTestCase extends BaseQueryTestCase {

	public QueryTestCase() {
		super("QueryTestCase");
	}

	

	public void testPseudoAndForSCG() {
		assertTrue(true);

	}

	public void testSimpleQuery() {
		Query query;
		SimpleConditionsNode simpleConditionsNode;
		query = QueryFactory.getInstance().newQuery(Query.SIMPLE_QUERY,
				Query.PARTICIPANT);
		try
		{
		query
				.addElementToView(new DataElement(Query.PARTICIPANT,
						"IDENTIFIER"));
		query.addElementToView(new DataElement(
				Query.PARTICIPANT_MEDICAL_IDENTIFIER, "IDENTIFIER"));
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		//        query.addElementToView(new DataElement(Query.COLLECTION_PROTOCOL,"IDENTIFIER"));
		//        query.addElementToView(new DataElement(Query.SPECIMEN,"IDENTIFIER"));
		

		try {
		    simpleConditionsNode = new SimpleConditionsNode(new Condition(
					new DataElement("Participant", "LAST_NAME"), new Operator(
							Operator.EQUAL), "'SHARMA'"),
					new Operator(Operator.AND));
			((SimpleQuery) query).addCondition(simpleConditionsNode);
			simpleConditionsNode = new SimpleConditionsNode(new Condition(
					new DataElement("Participant", "FIRST_NAME"), new Operator(
							Operator.EQUAL), "'aarti'"), new Operator(Operator.AND));
			((SimpleQuery) query).addCondition(simpleConditionsNode);

			simpleConditionsNode = new SimpleConditionsNode(new Condition(
					new DataElement(Query.COLLECTION_PROTOCOL_REGISTRATION,
							"REGISTRATION_DATE"), new Operator(Operator.EQUAL),
					"'2005-08-16'"), new Operator(Operator.AND));
			((SimpleQuery) query).addCondition(simpleConditionsNode);
			System.out.println("Query:\n" + query.getString());
		} catch (SQLException e) {
			e.printStackTrace();
			assertTrue(e.getMessage(),false);
		}
	}

	public void testAdvanceQuery() {
		Query query;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		try {
			query.addElementToView(new DataElement(Query.PARTICIPANT,
					"IDENTIFIER"));
			query.addElementToView(new DataElement(Query.COLLECTION_PROTOCOL,
					"IDENTIFIER"));
			query.addElementToView(new DataElement(
					Query.SPECIMEN_COLLECTION_GROUP, "IDENTIFIER"));
			query.addElementToView(new DataElement(Query.SPECIMEN,
					"PARENT_SPECIMEN_ID"));
			query
					.addElementToView(new DataElement(Query.SPECIMEN,
							"IDENTIFIER"));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		DefaultMutableTreeNode root = new DefaultMutableTreeNode();
		DefaultMutableTreeNode child1;
		DefaultMutableTreeNode child2;
		DefaultMutableTreeNode child3;
		DefaultMutableTreeNode child4;
		DefaultMutableTreeNode child5;
		DefaultMutableTreeNode child6;
		DefaultMutableTreeNode child7;
		DefaultMutableTreeNode child8;
		DefaultMutableTreeNode child10;
		
		try {
		AdvancedConditionsNode advancedConditionsNode = new AdvancedConditionsNode(
				Query.PARTICIPANT);
		
            advancedConditionsNode.addConditionToNode(new Condition(
            		new DataElement("Participant", "gender",
            				Constants.FIELD_TYPE_VARCHAR), new Operator(
            				Operator.EQUAL), "'Female'"));
       
		advancedConditionsNode.setOperationWithChildCondition(new Operator(
				Operator.OR));
		child1 = new DefaultMutableTreeNode(advancedConditionsNode);

		AdvancedConditionsNode advancedConditionsNode4 = new AdvancedConditionsNode(
				Query.COLLECTION_PROTOCOL);
		advancedConditionsNode4.setOperationWithChildCondition(new Operator(
				Operator.OR));
		child4 = new DefaultMutableTreeNode(advancedConditionsNode4);

		AdvancedConditionsNode advancedConditionsNode5 = new AdvancedConditionsNode(
				Query.SPECIMEN_COLLECTION_GROUP);
		//        advancedConditionsNode5.addConditionToNode(new Condition(new DataElement(Query.SPECIMEN,"tissue_site"),new Operator(Operator.EQUAL),"'lung'"));
		//        advancedConditionsNode5.addConditionToNode(new Condition(new DataElement(Query.SPECIMEN,"SPECIMEN_TYPE"),new Operator(Operator.EQUAL),"'tumor'"));
		advancedConditionsNode5.setOperationWithChildCondition(new Operator(
				Operator.EXIST));
		child5 = new DefaultMutableTreeNode(advancedConditionsNode5);

		AdvancedConditionsNode advancedConditionsNode6 = new AdvancedConditionsNode(
				Query.SPECIMEN);
		advancedConditionsNode6.addConditionToNode(new Condition(
				new DataElement(Query.SPECIMEN, "SPECIMEN_TYPE"), new Operator(
						Operator.EQUAL), "'non-malignant'"));
		advancedConditionsNode6.setOperationWithChildCondition(new Operator(
				Operator.OR));
		child6 = new DefaultMutableTreeNode(advancedConditionsNode6);

		AdvancedConditionsNode advancedConditionsNode9 = new AdvancedConditionsNode(
				Query.SPECIMEN_EVENT_PARAMETERS);
		advancedConditionsNode9.addConditionToNode(new Condition(
				new DataElement(Query.SPECIMEN_EVENT_PARAMETERS,
						"STORAGE_STATUS", Constants.FIELD_TYPE_VARCHAR),
				new Operator(Operator.EQUAL), "'CHECK IN'"));
		advancedConditionsNode9.setOperationWithChildCondition(new Operator(
				Operator.EXIST));
		child2 = new DefaultMutableTreeNode(advancedConditionsNode9);

		AdvancedConditionsNode advancedConditionsNode7 = new AdvancedConditionsNode(
				Query.SPECIMEN);
		advancedConditionsNode7.addConditionToNode(new Condition(
				new DataElement(Query.SPECIMEN, "tissue_site",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "lung"));
		advancedConditionsNode7.addConditionToNode(new Condition(
				new DataElement(Query.SPECIMEN, "SPECIMEN_TYPE",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "'tumor'"));
		advancedConditionsNode7.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN_EVENT_PARAMETERS,
						Query.SPECIMEN_EVENT_PARAMETERS, new Table(
								"CellSpecimenParam")), "STORAGE_STATUS",
						Constants.FIELD_TYPE_VARCHAR), new Operator(
						Operator.EQUAL), "'CHECK IN'"));
		advancedConditionsNode7.setOperationWithChildCondition(new Operator(
				Operator.OR));
		advancedConditionsNode7.setRuleForChild(false);
		child7 = new DefaultMutableTreeNode(advancedConditionsNode7);

		//        ((AdvancedQuery)query).addCondition(advancedConditionsNode);
		//        AdvancedConditionsNode advancedConditionsNode2 =new AdvancedConditionsNode(Query.SPECIMEN); 
		//        advancedConditionsNode2.addConditionToNode(new Condition(new DataElement("Sample","Type"),new Operator(Operator.EQUAL),"'RNA'"));
		//        advancedConditionsNode2.addConditionToNode(new Condition(new DataElement("Sample","Quantity"),new Operator(Operator.GREATER_THAN),"5"));
		//        child2 = new DefaultMutableTreeNode(advancedConditionsNode2);
		//
		//        //        System.out.println(((AdvancedQuery)query).addCondition(advancedConditionsNode,advancedConditionsNode2));
		AdvancedConditionsNode advancedConditionsNode3 = new AdvancedConditionsNode(
				Query.SPECIMEN);
		advancedConditionsNode3.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Type",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "DNA"));
		advancedConditionsNode3.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Quantity",
						Constants.FIELD_TYPE_BIGINT), new Operator(
						Operator.GREATER_THAN), "5"));
		advancedConditionsNode3.setOperationWithChildCondition(new Operator(
				Operator.OR));
		child3 = new DefaultMutableTreeNode(advancedConditionsNode3);

		AdvancedConditionsNode advancedConditionsNode10 = new AdvancedConditionsNode(
				Query.SPECIMEN);
		advancedConditionsNode10.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Type",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "RNA"));
		advancedConditionsNode10.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Quantity",
						Constants.FIELD_TYPE_BIGINT), new Operator(
						Operator.GREATER_THAN), "5"));
		child10 = new DefaultMutableTreeNode(advancedConditionsNode10);
		//        System.out.println(((AdvancedQuery)query).addCondition(advancedConditionsNode,advancedConditionsNode3));
		//        
		//        
		AdvancedConditionsNode advancedConditionsNode8 = new AdvancedConditionsNode(
				Query.SPECIMEN);
		advancedConditionsNode8.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Type",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "RNA"));
		advancedConditionsNode8.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "Quantity",
						Constants.FIELD_TYPE_BIGINT), new Operator(
						Operator.GREATER_THAN), "5"));
		child8 = new DefaultMutableTreeNode(advancedConditionsNode8);

		root.add(child1);
		child1.add(child4);
		child4.add(child5);
		child5.add(child6);
		child5.add(child7);
		child7.add(child3);
		child7.add(child8);
		child3.add(child10);
		//        child7.add(child8);
		//        child6.add(child2);
		//        child6.add(child3);

		((AdvancedConditionsImpl) ((AdvancedQuery) query).getWhereConditions())
				.setWhereCondition(root);
		
			Logger.out.debug("\n\n" + query.getString() + "\n\n");
		} catch (SQLException e1) {
			fail(e1.getMessage());
			e1.printStackTrace();
		}
	}

	public void testQuerySelectStringWhenNoResultViewSet() {
		Query query;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		String querySelectString = null;
		try {
			querySelectString = query.getQuerySelectString();
		} catch (SQLException e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
		System.out.println(querySelectString);
		assertNotNull(querySelectString);
	}

	public void testAddNullElementToResultView() {
		Query query;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		DataElement dataElement = null;
		try {
			query.addElementToView(dataElement);
			assertTrue(
					"Null pointer Exception not thrown when null parameter passed",
					false);
		}catch (NullPointerException e) {
			assertTrue(true);
		}catch (SQLException e) {
			e.printStackTrace();
			assertTrue(
					"Null pointer Exception not thrown when null parameter passed",
					false);
		}
	}


	public void testGetSelectStringWhenEmptyDataElementAdded() {
		Query query;
		String querySelectString=null;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		try
		{
			query.addElementToView(new DataElement());
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		try {
			querySelectString = query.getQuerySelectString();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		System.out.println(querySelectString);
		assertNull(querySelectString);
	}
	
	public void testGetSelectStringWhenNonEmptyDataElementAdded() {
		Query query;
		String querySelectString=null;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		try
		{
			query.addElementToView(new DataElement("Participant","lastname"));
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		try {
			querySelectString = query.getQuerySelectString();
		} catch (SQLException e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
		System.out.println(querySelectString);
		assertNotNull(querySelectString);
	}
	
	public void testDataElementCreationForUnknownObject()
	{
		DataElement dataElement = new DataElement("ABC","XYZ");
		try {
			dataElement.toSQLString(1);
			fail("Unknown object not caught");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void testFormFromStringWithNullInput()
	{
	    Query query;
		String queryFromString=null;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		HashSet tableSet = new HashSet();
		query.setTableSet(tableSet);
		try {
		    queryFromString = query.formFromString(null);
		    fail("Null table set not caught");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(queryFromString);
		assertNull(queryFromString);
	}
	
	public void testFormFromStringWithUnknownInput()
	{
	    Query query;
		String queryFromString=null;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		HashSet tableSet = new HashSet();
		tableSet.add("dummyTable");
		query.setTableSet(tableSet);
		try {
		    queryFromString = query.formFromString((HashSet) query.getTableSet());
		    fail("Dummy table not caught");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(queryFromString);
		assertNull(queryFromString);
	}
	
	public void testFormFromString()
	{
	    Query query;
		String queryFromString=null;
		query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
		HashSet tableSet = new HashSet();
		tableSet.add(Query.PARTICIPANT);
		tableSet.add(Query.SPECIMEN);
		query.setTableSet(tableSet);
		try {
		    queryFromString = query.formFromString((HashSet) query.getTableSet());
		    
		} catch (SQLException e) {
			e.printStackTrace();
			fail("Dummy table not caught");
		}
		System.out.println(queryFromString);
		assertNotNull(queryFromString);
	}
	
	public void testJoinConditionWithParentWhenBaseQuery()
	{
	    Query query;
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
	    String joinConditionStringWithParent = null;
	    try {
	        joinConditionStringWithParent = query.getJoinConditionWithParent((HashSet) query.getTableSet());
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
        assertEquals(joinConditionStringWithParent,new String());
	}
	
	public void testJoinConditionWithParentWhenNoRelation()
	{
	    //Forming Query
	    Query query;
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.SPECIMEN_COLLECTION_GROUP);
	    query.setParentOfQueryStartObject(Query.PARTICIPANT);
	    AdvancedConditionsNode childNode = new AdvancedConditionsNode(Query.COLLECTION_PROTOCOL);
	    DefaultMutableTreeNode child = new DefaultMutableTreeNode(childNode);
	    query.setTableSufix(2);
	    
	    String joinConditionStringWithParent = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        joinConditionStringWithParent = query.getJoinConditionWithParent((HashSet) query.getTableSet());
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
        assertEquals(joinConditionStringWithParent,new String());
	}
	
	public void testJoinConditionWithParentWhenRelationExists()
	{
	    //Forming Query
	    Query query;
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.COLLECTION_PROTOCOL);
	    query.setParentOfQueryStartObject(Query.PARTICIPANT);
	    query.setTableSufix(3);
	    
	    String joinConditionStringWithParent = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        joinConditionStringWithParent = query.getJoinConditionWithParent((HashSet) query.getTableSet());
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
        assertEquals(joinConditionStringWithParent, new String(" CollectionProtReg3.PARTICIPANT_ID = Participant2.IDENTIFIER  "));
	}
	
	public void testJoinConditionofSpecimenWithSpecimen()
	{
	    //Forming Query
	    Query query;
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.SPECIMEN);
	    query.setParentOfQueryStartObject(Query.SPECIMEN);
	    query.setTableSufix(3);
//	    query.setParentDerivedSpecimen(true);
	    
	    String joinConditionStringWithParent = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        joinConditionStringWithParent = query.getJoinConditionWithParent((HashSet) query.getTableSet());
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
        assertEquals(joinConditionStringWithParent," Specimen3.PARENT_SPECIMEN_ID = Specimen2.IDENTIFIER  ");
	}
	
	public void testJoinConditionofSpecimenWithSCG()
	{
	    //Forming Query
	    Query query;
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.SPECIMEN);
	    query.setParentOfQueryStartObject(Query.SPECIMEN_COLLECTION_GROUP);
	    query.setTableSufix(3);
//	    query.setParentDerivedSpecimen(true);
	    
	    String joinConditionStringWithParent = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        joinConditionStringWithParent = query.getJoinConditionWithParent((HashSet) query.getTableSet());
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
        assertEquals(joinConditionStringWithParent," Specimen3.IDENTIFIER = Specimen2.IDENTIFIER  ");
	}
	
	public void testJoinConditionWhenParentISDerivedSp()
	{
	    Query query = formQueryWithConditions();
	    
	    String joinConditionStringWithParent = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        joinConditionStringWithParent = query.getString();
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("joinConditionStringWithParent:"+joinConditionStringWithParent);
        assertNotNull(joinConditionStringWithParent);
	}
	
	

    public void testQueryWithpANDatSCGLevel()
	{
	    Query query = formQueryWithConditions();
	    
	    String queryString = null;
	    System.out.println(query.getTableNamesSet());
	    try {
	        queryString = query.getString();
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println(query.getTableNamesSet());
        System.out.println("queryString:"+queryString);
        assertNotNull(queryString);
	}
	
	/**
     * @return
     */
    private Query formQueryWithConditions() {
        //Forming Query
	    Query query;
	    HashSet tableSet = new HashSet();
	    tableSet.add(Query.COLLECTION_PROTOCOL_REGISTRATION);
	    tableSet.add(Query.COLLECTION_PROTOCOL_EVENT);
	    tableSet.add(Query.SPECIMEN);
	    
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
	    query.setTableSet(tableSet);
//	    query.setParentOfQueryStartObject(Query.PARTICIPANT);
//	    query.setTableSufix(3);
//	    query.setParentDerivedSpecimen(true);
	    DefaultMutableTreeNode root = new DefaultMutableTreeNode();
	    AdvancedConditionsNode pNode = new AdvancedConditionsNode(Query.PARTICIPANT);
	    DefaultMutableTreeNode p = new DefaultMutableTreeNode(pNode);
	    AdvancedConditionsNode cpNode = new AdvancedConditionsNode(Query.COLLECTION_PROTOCOL);
	    cpNode.setOperationWithChildCondition(new Operator(Operator.EXIST));
	    DefaultMutableTreeNode cp = new DefaultMutableTreeNode(cpNode);
	    AdvancedConditionsNode scgNode = new AdvancedConditionsNode(Query.SPECIMEN_COLLECTION_GROUP);
	    DefaultMutableTreeNode scg = new DefaultMutableTreeNode(scgNode);
	    AdvancedConditionsNode spNode1 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp1 = new DefaultMutableTreeNode(spNode1);
	    AdvancedConditionsNode spNode2 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp2 = new DefaultMutableTreeNode(spNode2);
	    AdvancedConditionsNode spNode3 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp3 = new DefaultMutableTreeNode(spNode3);
	    try
	    {
	    spNode1.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Tissue"));
	    spNode2.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Fluid"));
	    spNode3.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Molecular"));
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	        fail();
	    }
	    
	    root.add(p);
	    p.add(cp);
	    cp.add(scg);
	    scg.add(sp1);
	    sp1.add(sp2);
	    sp2.add(sp3);
	    ((AdvancedConditionsImpl)query.getWhereConditions()).setWhereCondition(root);
        return query;
    }
    
    private Query formQueryWithoutConditions() {
        //Forming Query
	    Query query;
	    HashSet tableSet = new HashSet();
	    tableSet.add(Query.COLLECTION_PROTOCOL_REGISTRATION);
	    tableSet.add(Query.COLLECTION_PROTOCOL_EVENT);
	    tableSet.add(Query.SPECIMEN);
	    
	    query = QueryFactory.getInstance().newQuery(Query.ADVANCED_QUERY,
				Query.PARTICIPANT);
	    query.setTableSet(tableSet);
//	    query.setParentOfQueryStartObject(Query.PARTICIPANT);
//	    query.setTableSufix(3);
//	    query.setParentDerivedSpecimen(true);
	    DefaultMutableTreeNode root = new DefaultMutableTreeNode();
	    AdvancedConditionsNode pNode = new AdvancedConditionsNode(Query.PARTICIPANT);
	    DefaultMutableTreeNode p = new DefaultMutableTreeNode(pNode);
	    AdvancedConditionsNode cpNode = new AdvancedConditionsNode(Query.COLLECTION_PROTOCOL);
	    cpNode.setOperationWithChildCondition(new Operator(Operator.EXIST));
	    DefaultMutableTreeNode cp = new DefaultMutableTreeNode(cpNode);
	    AdvancedConditionsNode scgNode = new AdvancedConditionsNode(Query.SPECIMEN_COLLECTION_GROUP);
	    DefaultMutableTreeNode scg = new DefaultMutableTreeNode(scgNode);
	    AdvancedConditionsNode spNode1 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp1 = new DefaultMutableTreeNode(spNode1);
	    AdvancedConditionsNode spNode2 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp2 = new DefaultMutableTreeNode(spNode2);
	    AdvancedConditionsNode spNode3 = new AdvancedConditionsNode(Query.SPECIMEN);
	    DefaultMutableTreeNode sp3 = new DefaultMutableTreeNode(spNode3);
	    try
	    {
	    spNode1.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Tissue"));
	    spNode2.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Fluid"));
	    spNode3.addConditionToNode(new Condition(
				new DataElement(new Table(Query.SPECIMEN, Query.SPECIMEN,
						new Table(Query.SPECIMEN, Query.SPECIMEN)), "specimen_class",
						Constants.FIELD_TYPE_TEXT),
				new Operator(Operator.EQUAL), "Molecular"));
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	        fail();
	    }
	    
	    root.add(p);
	    p.add(cp);
	    cp.add(scg);
	    scg.add(sp1);
	    sp1.add(sp2);
	    sp2.add(sp3);
	    ((AdvancedConditionsImpl)query.getWhereConditions()).setWhereCondition(root);
        return query;
    }

    public void testJoinConditionString()
	{
	    Query query = formQueryWithConditions();
	    HashSet set = (HashSet) query.getTableSet();
		set.addAll(query.getLinkingTables(set));
		set.addAll(query.getChildrenTables(set));
		Logger.out.debug("Set : " + set.toString());
		String joinConditionString = null ;
		try {
            joinConditionString = query.getJoinConditionString(set);
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println("joinConditionString:"+joinConditionString);
        assertEquals(joinConditionString,"CollectionProtReg1.IDENTIFIER   =  SpecimenCollectionGroup1.COLLECTION_PROTOCOL_REG_ID  AND CollectionProtocol1.IDENTIFIER   =  CollectionProtReg1.COLLECTION_PROTOCOL_ID  AND Participant1.IDENTIFIER   =  CollectionProtReg1.PARTICIPANT_ID  AND CollectionProtocolEvent1.IDENTIFIER   =  SpecimenCollectionGroup1.COLLECTION_PROTOCOL_EVENT_ID  AND CollectionProtocol1.IDENTIFIER   =  CollectionProtocolEvent1.COLLECTION_PROTOCOL_ID  AND SpecimenCollectionGroup1.IDENTIFIER   =  Specimen1.SPECIMEN_COLLECTION_GROUP_ID  ");
	}
    
    public void testJoinConditionWhenTableHasDifferentAliasInSimpleQuery()
    {
        String queryString = null;
        Query query = QueryFactory.getInstance().newQuery(Query.SIMPLE_QUERY,"Distribution");
        
        SimpleConditionsNode simpleConditionsNode;
        try{
        simpleConditionsNode = new SimpleConditionsNode(new Condition(
				new DataElement("Distribution", "identifier"), new Operator(
						Operator.EQUAL), "1"),
				new Operator(Operator.AND));
		((SimpleQuery) query).addCondition(simpleConditionsNode);
		simpleConditionsNode = new SimpleConditionsNode(new Condition(
				new DataElement(new Table("Address","AddressSite",new Table("Site")),"street"), new Operator(
						Operator.STARTS_WITH), "e"),
				new Operator(Operator.AND));
		((SimpleQuery) query).addCondition(simpleConditionsNode);
		
	
		    query.addElementToView(new DataElement("User","first_name"));
            query.addElementToView(new DataElement(new Table("Address","AddressSite",new Table("Site")),"STREET"));
            query.addElementToView(new DataElement(new Table("Address","AddressUser",new Table("User")),"STREET"));
            queryString = query.getString();
        } catch (SQLException e1) {
            e1.printStackTrace();
            fail();
        }
		System.out.println("simplequery:"+queryString);
		assertEquals(queryString,"Select User1.first_name  Column0 , AddressSite1.STREET  Column1 , AddressUser1.STREET  Column2 "
+"\nFROM  CATISSUE_SITE Site1 , CATISSUE_DISTRIBUTION Distribution1 , CATISSUE_ADDRESS AddressUser1 , CATISSUE_ADDRESS AddressSite1 , CATISSUE_USER User1  "  
+"\nWHERE Site1.IDENTIFIER   =  Distribution1.TO_SITE_ID  AND User1.IDENTIFIER   =  Distribution1.USER_ID  AND AddressUser1.IDENTIFIER   =  User1.ADDRESS_ID  AND AddressSite1.IDENTIFIER   =  Site1.ADDRESS_ID    AND ( ( UPPER(Distribution1.identifier ) = UPPER('1')   AND  UPPER(AddressSite1.street ) like UPPER('e%')  )    )");
    }
    
    public void testgetString()
    {
        Query query = formQueryWithConditions();
        String conditionsString = null;
        try {
            conditionsString = query.getWhereQueryString(null);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(" conditionsString:"+conditionsString);
    }
    
    
	
	
}

