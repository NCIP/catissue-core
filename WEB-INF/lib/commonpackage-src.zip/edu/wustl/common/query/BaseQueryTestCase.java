/*
 * Created on Aug 29, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.query;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;

import org.apache.log4j.PropertyConfigurator;

import edu.wustl.common.test.BaseTestCase;
import edu.wustl.common.util.logger.Logger;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BaseQueryTestCase extends BaseTestCase {

    /**
     * @param string
     */
    public BaseQueryTestCase(String string) {
        super(string);
    }

    protected void setUp() {
//		System
//				.setProperty("user.dir",
//						"E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore");
//		Variables.applicationHome = System.getProperty("user.dir");
//		System.out.println("Variables.applicationHome:"
//				+ Variables.applicationHome);
		Logger.out = org.apache.log4j.Logger.getLogger("");
		PropertyConfigurator
				.configure("E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore/Logger.properties");

		//		QueryBizLogic.initializeQueryData();
		//		Client.initializeDummy();
		File objectTableNamesFile = new File(
				"E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore/TestData/ObjectTableNames");
		File relationsFile = new File(
				"E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore/TestData/Relations");
		File privilegeTypeFile = new File(
				"E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore/TestData/privilegeType");
		FileInputStream fileInputStream;
		try {
			fileInputStream = new FileInputStream(objectTableNamesFile);
			ObjectInputStream inputStream = new ObjectInputStream(
					fileInputStream);
			Client.objectTableNames = (HashMap) inputStream.readObject();

			fileInputStream = new FileInputStream(relationsFile);
			inputStream = new ObjectInputStream(fileInputStream);
			Client.relationConditionsForRelatedTables = (HashMap) inputStream
					.readObject();

			fileInputStream = new FileInputStream(privilegeTypeFile);
			inputStream = new ObjectInputStream(fileInputStream);
			Client.privilegeTypeMap = (HashMap) inputStream.readObject();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
