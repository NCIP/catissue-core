/*
 * Created on Jul 24, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.query.test;

import org.apache.log4j.PropertyConfigurator;

import edu.wustl.common.bizlogic.QueryBizLogic;
import edu.wustl.common.query.Query;
import edu.wustl.common.query.QueryFactory;
import edu.wustl.common.test.BaseTestCase;
import edu.wustl.common.util.global.Variables;
import edu.wustl.common.util.logger.Logger;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class QueryTestCase extends BaseTestCase {

	public QueryTestCase()
	{
		super("QueryTestCase");
		
	}
	
	protected void setUp()
	{
//		System.setProperty("user.dir","E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore");
		Variables.applicationHome = System.getProperty("user.dir");
		System.out.println("Variables.applicationHome:"+Variables.applicationHome);
		Logger.out = org.apache.log4j.Logger.getLogger("");
		PropertyConfigurator.configure("E:/Program_Files/eclipse-SDK-3.0-win32/eclipse/workspace/catissuecore/Logger.properties");
		QueryBizLogic.initializeQueryData();
	}
	
	public void testPseudoAndForSCG()
	{
		assertTrue(true);
		
	}
}

