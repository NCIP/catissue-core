/*
 * Created on Aug 30, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.query;

import java.sql.SQLException;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdvancedConditionsImpTestCase extends QueryTestCase {

    /**
     * @param string
     */
    public AdvancedConditionsImpTestCase() {
        super();
    }
    
    public void testgetStringWithNoCondition()
    {
        AdvancedConditionsImpl advancedConditionsImpl = new AdvancedConditionsImpl();
        String conditionsString = null;
        try
        {
            conditionsString = advancedConditionsImpl.getString(1);
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
            fail();
        }
        System.out.println("conditionsString :"+conditionsString);
        assertEquals(conditionsString,"");
    }
    
    public void testgetStringWithCondition()
    {
        AdvancedConditionsImpl advancedConditionsImpl = new AdvancedConditionsImpl();
        AdvancedConditionsNode node1 = new AdvancedConditionsNode(Query.PARTICIPANT);
        node1.addConditionToNode(new Condition(new DataElement(Query.PARTICIPANT,"last_name"),new Operator(Operator.EQUAL),"sharma"));
        advancedConditionsImpl.addCondition(node1);
        AdvancedConditionsNode node2 = new AdvancedConditionsNode(Query.COLLECTION_PROTOCOL);
        node2.addConditionToNode(new Condition(new DataElement(Query.COLLECTION_PROTOCOL,"title"),new Operator(Operator.EQUAL),"sharma"));
        advancedConditionsImpl.addCondition(node1,node2);
        String conditionsString = null;
        try
        {
            conditionsString = advancedConditionsImpl.getString(1);
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
            fail();
        }
        System.out.println("conditionsString :"+conditionsString);
        assertEquals(conditionsString,"");
    }

}
