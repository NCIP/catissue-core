/*
 * Created on Aug 29, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.query;

import java.sql.SQLException;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SimpleConditionsImplTestCase extends QueryTestCase {

    /**
     * @param string
     */
    public SimpleConditionsImplTestCase() {
        super();
    }
    
    /**
     * 
     */
    public void testgetStringWhenNoCondition() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        String conditionsString = null;
        try {
            conditionsString = simpleConditionsImpl.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString," ");
    }
    
    public void testaddConditionWhenEmptyCondition() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        simpleConditionsImpl.addCondition(node1);
        String conditionsString = null;
        try {
            conditionsString = simpleConditionsImpl.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString,"  ");
    }
    
    public void testaddConditionWithNullParams() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        
        String conditionsString = null;
        try {
            node1.setCondition(new Condition(null,null,null));
            simpleConditionsImpl.addCondition(node1);
            conditionsString = simpleConditionsImpl.getString(1);
        } 
        catch (NullPointerException e) {
            e.printStackTrace();
            assertTrue(e.getMessage(),true);
        }catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString,null);
    }

    
    public void testaddConditionWithNullOperator() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        
        String conditionsString = null;
        try {
            node1.setCondition(new Condition(new DataElement("ABC","xyz"),new Operator(),""));
            simpleConditionsImpl.addCondition(node1);
            conditionsString = simpleConditionsImpl.getString(1);
        } 
       catch (SQLException e) {
            e.printStackTrace();
            assertTrue(e.getMessage(),true);
        }
        
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString,null);
    }
    
    public void testaddConditionWithUnknownTable() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        
        String conditionsString = null;
        try {
            node1.setCondition(new Condition(new DataElement("ABC","xyz"),new Operator(Operator.EQUAL),""));
            simpleConditionsImpl.addCondition(node1);
            conditionsString = simpleConditionsImpl.getString(1);
        } 
       catch (SQLException e) {
            e.printStackTrace();
            assertTrue(e.getMessage(),true);
        }
        
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString,null);
    }
    
    public void testaddConditionWithknownTable() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        
        String conditionsString = null;
        try {
            node1.setCondition(new Condition(new DataElement("Participant","xyz"),new Operator(Operator.EQUAL),""));
            simpleConditionsImpl.addCondition(node1);
            conditionsString = simpleConditionsImpl.getString(1);
        } 
       catch (SQLException e) {
            e.printStackTrace();
            assertTrue(e.getMessage(),true);
        }
        
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString," ( UPPER(Participant1.xyz ) = UPPER('')  )   ");
    }
    
    public void testgetString() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        SimpleConditionsNode node2 = new SimpleConditionsNode();
        SimpleConditionsNode node3 = new SimpleConditionsNode();
        
        String conditionsString = null;
        try {
            node3.setCondition(new Condition(new DataElement("Participant","first_name"),new Operator(Operator.EQUAL),"aarti"));
            node2.setCondition(new Condition(new DataElement("Participant","last_name"),new Operator(Operator.EQUAL),"sharma"));
            node1.setCondition(new Condition(new DataElement("Participant","ACTIVITY_STATUS"),new Operator(Operator.EQUAL),"Active"));
            simpleConditionsImpl.addCondition(node3);
            simpleConditionsImpl.addCondition(1,node1);
            simpleConditionsImpl.addCondition(1,node2);
            
            conditionsString = simpleConditionsImpl.getString(1);
        } 
       catch (SQLException e) {
            e.printStackTrace();
            fail();
        }
        
        System.out.println("conditions string:"+conditionsString);
        assertEquals(conditionsString," ( UPPER(Participant1.first_name ) = UPPER('aarti')   AND  UPPER(Participant1.last_name ) = UPPER('sharma')  )   AND UPPER(Participant1.ACTIVITY_STATUS ) = UPPER('Active') ");
    }
    
    public void testHasConditionsWhenTrue() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        node1.setCondition(new Condition(new DataElement("Participant","xyz"),new Operator(Operator.EQUAL),""));
        simpleConditionsImpl.addCondition(node1);
        assertTrue(simpleConditionsImpl.hasConditions());
    }
    
    public void testHasConditionsWhenFalse() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        simpleConditionsImpl.addCondition(node1);
        assertFalse(simpleConditionsImpl.hasConditions());
    }
    
    public void testHasConditionsExceptActivityStatusWhenTrue() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node1 = new SimpleConditionsNode();
        SimpleConditionsNode node2 = new SimpleConditionsNode();
        node1.setCondition(new Condition(new DataElement("Participant","xyz"),new Operator(Operator.EQUAL),""));
        node2.setCondition(new Condition(new DataElement("Participant","ACTIVITY_STATUS"),new Operator(Operator.EQUAL),"Active"));
        simpleConditionsImpl.addCondition(node1);
        simpleConditionsImpl.addCondition(node2);
        assertTrue(simpleConditionsImpl.hasConditionsExceptActivityStatus());
    }
    public void testHasConditionsExceptActivityStatusWhenFalse() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node2 = new SimpleConditionsNode();
        node2.setCondition(new Condition(new DataElement("Participant","ACTIVITY_STATUS"),new Operator(Operator.EQUAL),"Active"));
        simpleConditionsImpl.addCondition(node2);
        assertFalse(simpleConditionsImpl.hasConditionsExceptActivityStatus());
    }
    
    public void testhasConditionOnIdentifiedFieldWhenFalse() {
        SimpleConditionsImpl simpleConditionsImpl = new SimpleConditionsImpl();
        SimpleConditionsNode node2 = new SimpleConditionsNode();
        node2.setCondition(new Condition(new DataElement("Participant","ACTIVITY_STATUS"),new Operator(Operator.EQUAL),"Active"));
        simpleConditionsImpl.addCondition(node2);
        assertFalse(simpleConditionsImpl.hasConditionOnIdentifiedField());
    }
}
