package edu.wustl.common.util.tag;

import junit.framework.TestCase;
/*
 * Created on Jun 8, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.util.*;
/**
 * @author chetan_bh
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ScriptGeneratorTest extends TestCase {

	static Map shortDataMap;
	static Map longDataMap;
	
	public static void main(String[] args) {
	}

	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		
		shortDataMap = new Hashtable();
		longDataMap = new Hashtable();
		
		// construct simple Map
		Map containerMap = new Hashtable();
		
		Map xMap1 = new Hashtable();
		Map xMap2 = new Hashtable();

		List list1 = new ArrayList();
		list1.add("A");
		List list2 = new ArrayList();
		list2.add("B");
		List list3 = new ArrayList();
		list3.add("C");
		list3.add("D");
		
		xMap1.put("1",list1);
		xMap1.put("2",list2);

		xMap2.put("22",list3);

		shortDataMap.put("111",xMap1);
		shortDataMap.put("222",xMap2);
		
			
		//construct long Map
		containerMap = new Hashtable();
		
		xMap1 = new Hashtable();
		xMap2 = new Hashtable();

		list1 = new ArrayList();
		list1.add("A");
		list2 = new ArrayList();
		list2.add("B");
		list3 = new ArrayList();
		list3.add("C");
		list3.add("D");
		
		xMap1.put("1",list1);
		xMap1.put("2",list2);

		xMap2.put("22",list3);

		containerMap.put("111",xMap1);
		containerMap.put("222",xMap2);
		
		Map fourthMap = new Hashtable();
		fourthMap.put("@",containerMap);
		
		longDataMap.put("Hello",fourthMap);
	}

	/*
	 * @see TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetJSEquivalentFor() {
		assertNotNull(ScriptGenerator.getJSEquivalentFor(shortDataMap,"1"));
		assertNotNull(ScriptGenerator.getJSEquivalentFor(longDataMap,"2"));
	}

	public void testDepthOfMap() {
		assertEquals(ScriptGenerator.depthOfMap(shortDataMap),2);
		assertEquals(ScriptGenerator.depthOfMap(longDataMap),4);
	}

	public void testGetVarInStringForm() {
	}

}
