/**
 * 
 */
package edu.wustl.common.bizlogic.querySuite;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import edu.common.dynamicextensions.domain.DomainObjectFactory;
import edu.common.dynamicextensions.domaininterface.AssociationInterface;
import edu.common.dynamicextensions.domaininterface.EntityInterface;
import edu.common.dynamicextensions.entitymanager.EntityManager;
import edu.common.dynamicextensions.entitymanager.EntityManagerInterface;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.bizlogic.IBizLogic;
import edu.wustl.common.dao.DAOFactory;
import edu.wustl.common.dao.JDBCDAO;
import edu.wustl.common.tree.QueryTreeNodeData;
import edu.wustl.common.util.global.Constants;

/**
 * 
 * @author asawari_pawar
 *
 *This is the Biz logic class which has the API's to get the trees associated
 *with the categories/entity
 */
public class DefineAdvancedResultsView {
	
	public DefineAdvancedResultsView()
	{
		super();
	}
	
	public Vector getTreeForThisCategory(int categoryID)
	{
		
		try
		{
			
						
			JDBCDAO jdbcDao = (JDBCDAO)DAOFactory.getInstance().getDAO(Constants.JDBC_DAO);
	        jdbcDao.openSession(null);
	        
	        String [] selectColumnNames = {"ENTITY_ID"};
	        String [] whereColumnNames  = {"SEARCH_CATEGORY_ID"};
	        String[] whereColumnCondition = {"="};
	        Object[] whereColumnValue = { new Integer(categoryID)};
	        
	        //This gets all the root nodes associated with this category.
	        List entityList = jdbcDao.retrieve("CATISSUE_CATEGORY_TREES", selectColumnNames, whereColumnNames, whereColumnCondition, whereColumnValue, null);
	        
	        Iterator iter = entityList.iterator();
	        ResultSet resultSet = null;
	        while(iter.hasNext())
	        {
	        	List obj = (List)iter.next();
	        	
	        	EntityManagerInterface entityManagerInterface = EntityManager.getInstance();
				DomainObjectFactory factory = DomainObjectFactory.getInstance();
				
				Iterator iterList = obj.iterator();
				
				while(iterList.hasNext())
				{
					Vector<QueryTreeNodeData> treeData = new Vector<QueryTreeNodeData>();
					//Root node of the tree.
					Object entityObject = (Object)iterList.next();					
					EntityInterface entityInterface = entityManagerInterface.getEntityByIdentifier("2");
					
					//Form the root node 
					//String id = "ParentIdentifier1";
					//String displayName = "ParentNode1";
					QueryTreeNodeData rootNode = new QueryTreeNodeData();
					rootNode.setIdentifier(entityInterface.getId().toString());
					rootNode.setObjectName(entityInterface.getName());
					
					//Using the class name as the display name
					String [] strArr= entityInterface.getName().split(".");
					rootNode.setDisplayName(strArr[strArr.length-1]);
					rootNode.setParentIdentifier("0");
					rootNode.setParentObjectName("");
					treeData.add(rootNode);					
					
					//The association of the entities will form the child nodes.
					Iterator iterAssociations =entityInterface.getAssociationCollection().iterator();
					
					while(iterAssociations.hasNext())
					{
						
						AssociationInterface assInterface = (AssociationInterface)iterAssociations.next();
						//Source entity is the parent entity. 
						EntityInterface parentEntity = assInterface.getEntity();
						
						//Target entity is the child entity.
						EntityInterface childEntity = assInterface.getTargetEntity();
						
						QueryTreeNodeData childNode = new QueryTreeNodeData();
						
						childNode.setIdentifier(childEntity.getId().toString());
						childNode.setObjectName(childEntity.getName());
						
						//Using the class name as the display name
						
						strArr= childEntity.getName().split(".");
						childNode.setDisplayName(strArr[strArr.length-1]);
						childNode.setParentIdentifier(parentEntity.getId().toString());
						childNode.setParentObjectName(parentEntity.getName());
						treeData.add(childNode);			
						
						
						
					}					
					
					System.out.println("Entity Interface Name " + entityInterface.getName());
					return treeData;
	        	
				}
	        	
	        }
	        	             
	        
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	};
	
}
