import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import edu.wustl.common.util.global.Constants;
import edu.wustl.common.util.global.Variables;


/**
 * @author prafull_kadam
 *
 */
public class connect2
{

	public static void main (String[] args)
    {
        Connection conn = null;
		boolean displayAll =false;

		String ss = "Select DISTINCT Column33, Column34, Column35, Column36, Column37, Column38, Column39, Column40, Column41, Column42, Column43, Column44, Column45, Column46, Column47, Column48, Column49, Column50, Column51, Column52 From CATISSUE_QUERY_RESULTS_1 WHERE Column32=1 ORDER BY Column52";
		
		Variables.databaseName = Constants.ORACLE_DATABASE;
		
//		System.out.println(putPageNumInSQL(ss,1,100,false));
//		if (true)
//			return;
        try
        {
            String userName = "root";
//            String password = "persistent";
//            String url = "jdbc:mysql://localhost/catissue10kp";
            String password = "";
            String url = "jdbc:mysql://10.79.0.115/catissue20kp";

            String displayString = "";

            int noOfRecords=100;
    		int startIndex =-1;
    		
    		boolean isMySQL = true;
    		boolean delay = true;
            if (args.length!=0)	
            {
            	if (args[0].equals("oracle"))
            	{
                  userName = "catissue_prafull";
                  password = "catissue_prafull";
                  url = "jdbc:oracle:thin:@10.88.199.74:1521:washu";
                  Class.forName ("oracle.jdbc.driver.OracleDriver").newInstance ();
                  isMySQL = false;
                  displayString = "Oracle\t|\t";
            	}
            	else
            	{
                    userName = "root";
                    password = "";
                    url = "jdbc:mysql://10.79.0.115/catissue20kp";
            		Class.forName ("com.mysql.jdbc.Driver").newInstance ();
            		isMySQL = true;
                    displayString = "mysql\t|\t";
            	}
            	if (args.length>1)
            	{
            		startIndex = Integer.parseInt(args[1]);
            		noOfRecords = Integer.parseInt(args[2]);
                	if (args.length>3)
                		delay = true;
            	}
            }
            else
            {
            	System.out.println("Usage:");
            	System.out.println("java connect2 <oracle/mysql> [<startIndex> <noOfRecords>] [delay]");
            	return;
            }

            if (delay)
            	Thread.sleep(10000);
            long startTime = System.currentTimeMillis();
            conn = DriverManager.getConnection (url, userName, password);
            System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
            if (displayAll) System.out.println ("Database connection established with " +(isMySQL? "MySQL":"Oracle") + " Database...");

            String originalQuery = "Select identifier id, specimen_class sp, type tp, label lb, lineage ln, created_on_date cr From catissue_specimen sp order by identifier";
            String query = originalQuery;
            
    		long time = System.currentTimeMillis();

    		
    		if (startIndex==-1)
    		{
    			if (displayAll) System.out.println("Fetching all records....");
    			displayString+="All\t|\t";
    		}
    		else
    		{
    			if (displayAll) System.out.println("Getting records from :" + startIndex + " & Total records to be fetched: " + noOfRecords );
    			query = putPageNumInSQL(originalQuery, startIndex, noOfRecords, isMySQL);
    			displayString+=startIndex +"\t|\t";
    		}
    		if (displayAll) System.out.println("SQL:"+query);
    		PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
    		ResultSet resultSet = stmt.executeQuery();
    		if (displayAll) System.out.println("ExecuteQuery Time:"+(System.currentTimeMillis()-time));
    		
    		displayString+= (System.currentTimeMillis()-time)+"\t|\t";
    		time = System.currentTimeMillis();
    		ResultSetMetaData metaData = resultSet.getMetaData();
    		int columnCount = metaData.getColumnCount();
    		
    		List list = new ArrayList();
    		while (resultSet.next())
			{
    			List aList = new ArrayList();
    			int i=1;
    			while (i <= columnCount)
				{
					if (resultSet.getObject(i) != null)
					{
						Object valueObj = resultSet.getObject(i);
						if (valueObj instanceof oracle.sql.CLOB)
						{
							aList.add(valueObj);
						}
						else
						{
							String value;
							// Sri: Added check for date/time/timestamp since the
							// default date format returned by toString was yyyy-dd-mm
							// bug#463 
							if (valueObj instanceof java.util.Date) // since all java.sql time 
							//classes are derived from java.util.Date 
							{
								SimpleDateFormat formatter = new SimpleDateFormat(
										Constants.DATE_PATTERN_MM_DD_YYYY);
								value = formatter.format((java.util.Date) valueObj);
							}
							else
							{
								value = valueObj.toString();
							}
							aList.add(value);
						}
					}
					else
					{
						aList.add("");
					}
					i++;
				}
    			list.add(aList);
			}
    		if (displayAll) System.out.println("Iteration time:"+(System.currentTimeMillis()-time) + ": For no of Records:"+list.size());
    		
    		displayString+=(System.currentTimeMillis()-time)+"\t|\t";
    		time = System.currentTimeMillis();
    		String countQuery = getCountQuery(originalQuery);
    		resultSet.close();
    		resultSet = stmt.executeQuery(countQuery);
    		resultSet.next();
    		int totalRecords = resultSet.getInt(1);
    		if (displayAll) System.out.println("Finding Count of records Time:"+(System.currentTimeMillis()-time)+": Records:"+totalRecords);
    		displayString+=(System.currentTimeMillis()-time)+"\t\t|\t";
    		resultSet.close();
    		stmt.close();
            long endTime = System.currentTimeMillis();
            if (displayAll) System.out.println("Total Time taken"+(endTime-startTime));
            displayString+=(endTime-startTime)+"\t|\t" +(startIndex==-1?totalRecords:list.size()) +"/" + totalRecords;
            if (delay)
            	Thread.sleep(10000);
            
            if (!displayAll)
            {
            	System.out.println(displayString);
            }
    		
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (conn != null)
            {
                try
                {
                    conn.close ();
                    if (displayAll) System.out.println ("Database connection terminated");
                }
                catch (Exception e) { /* ignore close errors */ }
            }
        }
    }
	
	private static final String SELECT_CLAUSE = "SELECT";
	private static final String FROM_CLAUSE = " FROM";
	private static final String DISTINCT_CLAUSE = "DISTINCT ";

	private static String putPageNumInSQL(String sql, int startIndex, int noOfRecords, boolean isMySQL)
	{
		StringBuffer newSql = new StringBuffer();
		if (Variables.databaseName.equals(Constants.MYSQL_DATABASE))
		{
			// Add limit clause for the MYSQL case
			newSql.append(sql).append(" Limit ").append(startIndex).append(" , ").append(
					noOfRecords);
		}
		else
		{
			//Add rownum condition to the query, by forming outer query.
			String upperCaseSQL = sql.toUpperCase();
			int index = upperCaseSQL.indexOf(SELECT_CLAUSE) + SELECT_CLAUSE.length();
			int fromIndex = upperCaseSQL.indexOf(FROM_CLAUSE);

			String selectAttributes = sql.substring(index, fromIndex).trim();

			boolean addDistinctClause = false;
			if (selectAttributes.startsWith(DISTINCT_CLAUSE))
			{
				selectAttributes = selectAttributes.substring(DISTINCT_CLAUSE.length());
				selectAttributes.trim();
				addDistinctClause = true;
			}
			String[] selectAttributeArray = selectAttributes.split(",");

			StringBuffer outerQuerySelectAttributes = new StringBuffer(" ");

			for (int i = 0; i < selectAttributeArray.length; i++)
			{
				String attribute[] = selectAttributeArray[i].trim().split(" ");
				String attributeName = attribute[0];
				if (attribute.length > 1)
				{
					attributeName = attribute[attribute.length - 1];
				}
				outerQuerySelectAttributes.append(attributeName).append(" ,");
			}
			int outerQuerySelectAttributesLength = outerQuerySelectAttributes.length();
			outerQuerySelectAttributes.delete(outerQuerySelectAttributesLength - 2,
					outerQuerySelectAttributesLength);
			newSql.append(SELECT_CLAUSE).append(" ");
			
			if (addDistinctClause)
				newSql.append(DISTINCT_CLAUSE);
			
			newSql.append(outerQuerySelectAttributes).append(" FROM (").append(SELECT_CLAUSE).append(
					" rownum rn, ").append(selectAttributes).append(sql.substring(fromIndex))
					.append(")").append(" WHERE rn BETWEEN ").append(startIndex).append(" AND ")
					.append(startIndex + noOfRecords - 1);

		}
		return newSql.toString();
	}
	
	private static String getCountQuery(String originalQuery)
	{
		return "Select count(*) from (" + originalQuery+") alias";
	}
}
