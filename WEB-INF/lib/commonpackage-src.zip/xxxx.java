
/**
 * 
 */

/**
 * @author supriya_dankh
 *
 */
public class xxxx
{
public static void main(String[] args)
{
	String str = "newtestform-test=+";
	
	str = str.replaceAll("[: \\+\\*/()?\\^&!~@%#$.,-=]","");
	
	System.out.println(str);
}
}
