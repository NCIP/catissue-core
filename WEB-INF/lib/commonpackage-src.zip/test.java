
public class test {
 public static void main(String[] args) {
	String a = "aa";
	String A = "A";
	System.out.println(a.compareToIgnoreCase(A));
}
}
