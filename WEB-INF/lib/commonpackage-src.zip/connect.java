import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import edu.wustl.common.util.global.Constants;


/**
 * 
 */

/**
 * @author prafull_kadam
 *
 */
public class connect
{

	public static void main (String[] args)
    {
        Connection conn = null;

        try
        {
            String userName = "root";
            String password = "";
            String url = "jdbc:mysql://10.79.0.115/catissue20kp";
            Class.forName ("com.mysql.jdbc.Driver").newInstance ();

//            String userName = "catissue_prafull";
//            String password = "catissue_prafull";
//            String url = "jdbc:oracle:thin:@10.88.199.74:1521:washu";
//            Class.forName ("oracle.jdbc.driver.OracleDriver").newInstance ();
 
            System.out.println("start.....");
//            Thread.sleep(10000);
            long startTime = System.currentTimeMillis();
            conn = DriverManager.getConnection (url, userName, password);
            System.out.println ("Database connection established");
            
            String query  = "Select Specimen1.BARCODE  Column0 , Specimen1.LABEL  Column1 , ExternalIdentifier1.NAME  Column2 , ExternalIdentifier1.VALUE  Column3 , Specimen1.SPECIMEN_COLLECTION_GROUP_ID  Column4 , Specimen1.SPECIMEN_CLASS  Column5 , Specimen1.TYPE  Column6 , Specimen1.LINEAGE  Column7 , Specimen1.PARENT_SPECIMEN_ID  Column8 , SpecimenCharacteristics1.TISSUE_SIDE  Column9 , SpecimenCharacteristics1.TISSUE_SITE  Column10 , Specimen1.PATHOLOGICAL_STATUS  Column11 , Specimen1.QUANTITY  Column12 , Specimen1.AVAILABLE_QUANTITY  Column13 , Specimen1.CONCENTRATION  Column14 , Specimen1.AVAILABLE  Column15 , Specimen1.POSITION_DIMENSION_ONE  Column16 , Specimen1.POSITION_DIMENSION_TWO  Column17 , Specimen1.CREATED_ON_DATE  Column18 , Specimen1.IDENTIFIER  Column19 " 
            + "FROM  CATISSUE_SPECIMEN_CHAR SpecimenCharacteristics1 , CATISSUE_EXTERNAL_IDENTIFIER ExternalIdentifier1 , CATISSUE_SPECIMEN Specimen1 "  
            + "WHERE SpecimenCharacteristics1.IDENTIFIER   =  Specimen1.SPECIMEN_CHARACTERISTICS_ID  AND Specimen1.IDENTIFIER   =  ExternalIdentifier1.SPECIMEN_ID    AND ( ( UPPER(Specimen1.BARCODE ) like UPPER('%')  )   AND UPPER(Specimen1.ACTIVITY_STATUS ) != UPPER('Disabled')  ) "
            +"ORDER BY Specimen1.IDENTIFIER ,SpecimenCharacteristics1.IDENTIFIER ,ExternalIdentifier1.IDENTIFIER  ";
//            String query = "Select * From catissue_specimen order by identifier";
            
    		long time = System.currentTimeMillis();
    		PreparedStatement stmt = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
    		ResultSet resultSet = null;
    		long exeTime = System.currentTimeMillis();
    		resultSet = stmt.executeQuery();
    		long exeEndTime = System.currentTimeMillis();
    		System.out.println("EXEXEXEXEXE:"+(exeEndTime-exeTime));
    		int noOfRecords=100;
    		int startIndex =100;

    		if (startIndex==-1)
    			System.out.println("Fetching all records....");
    		else
    		{
    			System.out.println("Getting records from :" + startIndex + " & Total records to be fetched: " + noOfRecords );
//    			query+= " limit " + startIndex +" , " + noOfRecords;
    		}
    		System.out.println("SQL:"+query);
    		System.out.println("ExecuteQuery Time:"+(System.currentTimeMillis()-time));
    		time = System.currentTimeMillis();
    		boolean getSublistOfResult = startIndex !=-1;
    		if (getSublistOfResult)
			{
				resultSet.absolute(startIndex);
				System.out.println("Time taken for Absoulute:"+(System.currentTimeMillis()-time));
				time = System.currentTimeMillis();
			}
			else
			{
				noOfRecords = Integer.MAX_VALUE;
			}
    		ResultSetMetaData metaData = resultSet.getMetaData();
    		int columnCount = metaData.getColumnCount();
    		
    		int recordCount = 0;
    		List list = new ArrayList();
    		while (resultSet.next() && recordCount < noOfRecords)
			{
    			List aList = new ArrayList();
    			int i=1;
    			while (i <= columnCount)
				{
					if (resultSet.getObject(i) != null)
					{
						Object valueObj = resultSet.getObject(i);
						if (valueObj instanceof oracle.sql.CLOB)
						{
							aList.add(valueObj);
						}
						else
						{
							String value;
							// Sri: Added check for date/time/timestamp since the
							// default date format returned by toString was yyyy-dd-mm
							// bug#463 
							if (valueObj instanceof java.util.Date) // since all java.sql time 
							//classes are derived from java.util.Date 
							{
								SimpleDateFormat formatter = new SimpleDateFormat(
										Constants.DATE_PATTERN_MM_DD_YYYY);
								value = formatter.format((java.util.Date) valueObj);
							}
							else
							{
								value = valueObj.toString();
							}
							aList.add(value);
						}
					}
					else
					{
						aList.add("");
					}
					i++;
				}
    			list.add(aList);
//    			if (getSublistOfResult)
//    				Thread.sleep(10);
				recordCount++;
			}
    		System.out.println("Iteration time:"+(System.currentTimeMillis()-time) + ": For no of Records:"+list.size());
    		time = System.currentTimeMillis();
    		resultSet.last();
    		System.out.println("Total Recorsd:"+resultSet.getRow());
    		System.out.println("Time taken to move cursor at last:"+(System.currentTimeMillis()-time));
    		time= System.currentTimeMillis();
            System.out.println("Done........");
            long endTime = System.currentTimeMillis();
            System.out.println("Done........Total Time taken"+(endTime-startTime));
//    		Thread.sleep(10000);
    		
        }
        catch (Exception e)
        {
            System.err.println ("Cannot connect to database server");
        }
        finally
        {
            if (conn != null)
            {
                try
                {
                    conn.close ();
                    System.out.println ("Database connection terminated");
                }
                catch (Exception e) { /* ignore close errors */ }
            }
        }
    }
}
