import java.sql.SQLException;

import edu.wustl.common.dao.queryExecutor.AbstractQueryExecutor;
import edu.wustl.common.dao.queryExecutor.PagenatedResultData;
import edu.wustl.common.util.global.Constants;
import edu.wustl.common.util.global.Variables;



public class tryClass extends AbstractQueryExecutor
{
	public static void main(String[] args)
	{
		Variables.databaseName = Constants.ORACLE_DATABASE;
		tryClass qry = new tryClass();
//		String SQL = "Select Distribution1.IDENTIFIER  Column0 , TO_DATE(TO_CHAR(Distribution1.EVENT_TIMESTAMP ,'mm-dd-yyyy'),'mm-dd-yyyy') Column1 , TO_CHAR(Distribution1.EVENT_TIMESTAMP ,'hh-mi-ss')  Column2 , DistributedItem1.QUANTITY  Column3 , Specimen1.IDENTIFIER  Column4 , Specimen1.TYPE  Column5 , SpecimenCharacteristics1.TISSUE_SITE  Column6 , SpecimenCharacteristics1.TISSUE_SIDE  Column7 , Specimen1.PATHOLOGICAL_STATUS  Column8 " 
//					+ "FROM  CATISSUE_SPECIMEN_CHAR SpecimenCharacteristics1 , CATISSUE_SPECIMEN Specimen1 , CATISSUE_DISTRIBUTED_ITEM DistributedItem1 , CATISSUE_DISTRIBUTION Distribution1 "  
//					+ "WHERE SpecimenCharacteristics1.IDENTIFIER   =  Specimen1.SPECIMEN_CHARACTERISTICS_ID  AND Specimen1.IDENTIFIER   =  DistributedItem1.SPECIMEN_ID  AND Distribution1.IDENTIFIER   =  DistributedItem1.DISTRIBUTION_ID    AND ( ( Distribution1.IDENTIFIER  IS NOT NULL  )   AND UPPER(Specimen1.ACTIVITY_STATUS ) != UPPER('Disabled')   AND UPPER(Distribution1.ACTIVITY_STATUS ) != UPPER('Disabled')  ) "
//					+ "ORDER BY Distribution1.IDENTIFIER ,DistributedItem1.IDENTIFIER ,SpecimenCharacteristics1.IDENTIFIER ,Specimen1.IDENTIFIER ";
//		String SQL  = "Select Participant1.LAST_NAME  Column0 , Participant1.FIRST_NAME  Column1 , Participant1.MIDDLE_NAME  Column2 , Participant1.BIRTH_DATE  Column3 , Participant1.GENDER  Column4 , Participant1.GENOTYPE  Column5 , Participant1.ETHNICITY  Column6 , Participant1.SOCIAL_SECURITY_NUMBER  Column7 , Participant1.VITAL_STATUS  Column8 , Participant1.DEATH_DATE  Column9 , Participant1.IDENTIFIER  Column10 " 
//					+ "FROM  CATISSUE_PARTICIPANT Participant1 "
//					+ "WHERE   ( UPPER(Participant1.LAST_NAME ) like UPPER('%')  )   AND UPPER(Participant1.ACTIVITY_STATUS ) != UPPER('Disabled') " 
//					+ "ORDER BY Participant1.IDENTIFIER ";
		
		String SQL = "Select Specimen1.BARCODE  Column0 , Specimen1.LABEL  Column1 , ExternalIdentifier1.NAME  Column2 , ExternalIdentifier1.VALUE  Column3 , Specimen1.SPECIMEN_COLLECTION_GROUP_ID  Column4 , Specimen1.SPECIMEN_CLASS  Column5 , Specimen1.TYPE  Column6 , Specimen1.LINEAGE  Column7 , Specimen1.PARENT_SPECIMEN_ID  Column8 , SpecimenCharacteristics1.TISSUE_SIDE  Column9 , SpecimenCharacteristics1.TISSUE_SITE  Column10 , Specimen1.PATHOLOGICAL_STATUS  Column11 , Specimen1.QUANTITY  Column12 , Specimen1.AVAILABLE_QUANTITY  Column13 , Specimen1.CONCENTRATION  Column14 , Specimen1.AVAILABLE  Column15 , Specimen1.POSITION_DIMENSION_ONE  Column16 , Specimen1.POSITION_DIMENSION_TWO  Column17 , Specimen1.CREATED_ON_DATE  Column18 , Specimen1.IDENTIFIER  Column19 "
				+ "FROM  CATISSUE_SPECIMEN_CHAR SpecimenCharacteristics1 , CATISSUE_EXTERNAL_IDENTIFIER ExternalIdentifier1 , CATISSUE_SPECIMEN Specimen1 "
				+ "WHERE SpecimenCharacteristics1.IDENTIFIER   =  Specimen1.SPECIMEN_CHARACTERISTICS_ID  AND Specimen1.IDENTIFIER   =  ExternalIdentifier1.SPECIMEN_ID    AND ( ( Specimen1.IDENTIFIER  IS NOT NULL  )   AND UPPER(Specimen1.ACTIVITY_STATUS ) != UPPER('Disabled')  ) "
				+ "ORDER BY Specimen1.IDENTIFIER ,SpecimenCharacteristics1.IDENTIFIER ,ExternalIdentifier1.IDENTIFIER";
//		String SQL = "select distinct type t, specimen_class c, label From catissue_specimen";
		
		System.out.println(qry.getCountQuery(SQL)+";\n");
		String modifiedSQL = qry.putPageNumInSQL(SQL,0,100);
		
//		System.out.println(qry.getCountQuery(modifiedSQL)+";");
		System.out.println(qry.getCountQuery(qry.putPageNumInSQL(SQL,100,100)) +";");
		System.out.println(qry.getCountQuery(qry.putPageNumInSQL(SQL,1000,100)) +";");
		System.out.println(qry.getCountQuery(qry.putPageNumInSQL(SQL,1000,100)) +";");
		System.out.println(qry.getCountQuery(qry.putPageNumInSQL(SQL,10000,100)) +";");
		System.out.println(qry.getCountQuery(qry.putPageNumInSQL(SQL,90000,100)) +";");
		
		
		System.out.println(qry.putPageNumInSQL(SQL,90000,100));
		System.out.println(qry.putPageNumInSQL(SQL,90000,100));
//		System.out.println(qry.getCountQuery(qry.putPageNumInSQLOld(SQL,90000,50))+";");
		
	}

	@Override
	protected PagenatedResultData createStatemtentAndExecuteQuery() throws SQLException
	{
		// TODO Auto-generated method stub
		return null;
	} 
}
